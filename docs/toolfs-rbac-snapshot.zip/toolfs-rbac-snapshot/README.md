# ToolFS 设计文档索引

## 当前版本

**[`design-rbac-snapshot.md`](design-rbac-snapshot.md) —— v5（2026-07-29）**，最新一版设计稿。

> ⚠️ **全部文档均处于设计稿阶段**，尚未评审、未确认，**不作为实施依据**。代码尚未开始。
> 若要讨论或实施，以 v5 为准；历史版本归档在 [`history/`](history/)，仅供追溯决策来由。

---

## 1. 版本演进一览

| 版本 | 日期 | 文件 | 核心主张 | 为何被取代 |
|---|---|---|---|---|
| v1 | 07-23 | [`history/v1-toolfs-own-policy-initial.md`](history/v1-toolfs-own-policy-initial.md) | ToolFS 自建一套 Policy 配置文件（JSON/YAML）定义「角色→路径→操作」 | 实证复核发现事实错误与危险默认值 |
| v2 | 07-25 | [`history/v2-toolfs-own-policy.md`](history/v2-toolfs-own-policy.md) | v1 + 新增 P0 路径安全阶段 + state 目录移出 mount + 修正快照默认值 | 全栈调查发现自建授权体系方向错误 |
| v3 | 07-25 | [`history/v3-consume-zimaos-grants.md`](history/v3-consume-zimaos-grants.md) | 改为消费 ZimaOS 既有授权（share 表）；快照延后；per-user 挂载视图确立为核心交付物 | 安全评审发现接口选型与 IO 模型不足以支撑安全承诺 |
| v4 | 07-26 | [`history/v4-descriptor-based-grants.md`](history/v4-descriptor-based-grants.md) | 逐行 Grant 契约 + descriptor-based IO + SessionView/MountHandle + per-device StateRoot | 快照/闪回整章缺失，且 versions 只写不读 |
| **v5** | **07-29** | **[`design-rbac-snapshot.md`](design-rbac-snapshot.md)** | 补齐快照与闪回：快照/闪回分权、三层恢复源、btrfs backend、`.toolfs-state` 独立 subvolume | **现行** |

> **v1/v2 文件说明**：两者都从未提交进 git，磁盘副本在后续写入时被覆盖。现存文件是依据会话记录重建的（v1 为原始写入内容，v2 为 v1 + 全部 v2 编辑），内容应当一致，但未做字节级校验。
>
> ⚠️ **v1 的 §3.2 含一处已知事实错误**——它写「复用 `normalizeVirtualPath`（防 `../` 逃逸）」，该函数实际不清理 `..`。这个错误正是 v2 新增 P0 阶段的起因，重建时予以保留以还原历史原貌，**阅读时请勿采信**。

---

## 2. 关键决策的演进

这张表是本索引最有价值的部分——它记录了每个决策**为什么变成现在这样**，避免重新讨论已经settled 的问题。

| 议题 | v1 | v2 | v3 | v4 | v5（现行） |
|---|---|---|---|---|---|
| **授权来源** | ToolFS 自有 Policy 文件 | 同 v1 | ZimaOS share 表，经 `/share` 聚合接口 | ZimaOS share 表，经**新增逐行 Grant API** | 同 v4 |
| **路径安全** | 误认为 `normalizeVirtualPath` 可防 `../` | `sanitizeVirtualPath` + `EvalSymlinks` | 同 v2，前移到真实路径鉴权 | **descriptor-based**（dirfd + `openat2`） | 同 v4，并覆盖快照内读取 |
| **StateDir** | mount 内 `.toolfs-trash/` | mount 外固定 `/var/lib/toolfs` | 同 v2 | **per-device** `.toolfs-state/` | 同 v4，且**必须是独立 subvolume** |
| **FUSE 按用户视图** | P5，最后 | P5，最后 | P4，核心交付物 | **P2，只读切片前移** | 同 v4 |
| **操作粒度** | read/list/write/delete/execute | 同 v1 | 同 + delete 默认不给 | read/list/**create/modify**/delete；`OpExecute` 移出 FS 边界 | 同 v4 |
| **admin 语义** | `AdminFullAccess` 全放行 | 同 + 显式 deny 可覆盖 | 路径维度全放行 | 受 PublicRoots 硬上界约束 | **数据驱动：也只按 share 表构建视图，无 `if role==admin` 旁路**；`role` 仅用于管理操作准入 |
| **快照/闪回** | btrfs+copy+memory 三后端 | 同，修正危险默认值 | 延后 | 延后（且 versions 只写不读） | **快照/闪回分权 + 三层恢复源；仅 btrfs，去掉 copy 降级** |
| **JWT 验签** | 按 `kid` 查 JWKS | 同 | 同 | **兼容无 `kid` 的 JWKS**；`AllowStaleKeys` 默认 false | 同 v4 |
| **工期估算** | 19 人天 | 21 人天 | 16 人天 | 15–21 人天 + 3–5 联调 | **+6–9 人天**（P5a–P5d） |

---

## 3. 已被否决的设计（不要重新提出）

| # | 设计 | 出现于 | 否决原因 |
|---|---|---|---|
| 1 | ToolFS 自建 Policy 配置文件定义权限 | v1, v2 | 造成**第二套权限真相**：管理员在 ZimaOS UI 改的权限 ToolFS 不知道，反之亦然。分歧即安全事故 |
| 2 | 用 `/v2_1/files/share` 聚合接口作授权输入 | v3 | 面向 UI 的路径聚合模型，无法表达「同一路径下某用户记录已删除、其他用户仍有效」，不适合作安全契约 |
| 3 | 用 `/share/permission?username=` 作授权输入 | （曾评估） | handler 未过滤 `is_deleted`，会把已禁用共享当有效权限返回，**造成权限放大** |
| 4 | `EvalSymlinks` + 路径字符串作为安全句柄 | v2, v3 | **不能消除 TOCTOU**：检查与使用之间，父目录或软链仍可被 SMB/其他进程替换；`O_NOFOLLOW` 只保护最终分量 |
| 5 | 固定 `/var/lib/toolfs` 作 StateDir | v2, v3 | 通常与 `/DATA`、外接盘不同文件系统，`os.Rename` 返回 `EXDEV`，保护链直接失效 |
| 6 | state 目录放在 mount 内部 | v1 | copy 型快照第 N 次会把第 N-1 次整个拷进去（指数膨胀）；`filepath.Walk` 会把回收站读进内存 |
| 7 | `MemoryBackend` 作为生产降级路径 | v1 | `FileSnapshot.Content []byte` 把每个文件完整内容常驻内存，真实数据量下必然 OOM |
| 8 | `SnapshotOnDeleteDirs` 默认 true | v1 | btrfs 不可用时，agent 删一个目录就触发整挂载（可能 TB 级）全量拷贝 |
| 9 | 由 FUSE 强制 `OpExecute` | v1–v3 | FUSE 无法阻止进程先读脚本再 `bash script.sh`。执行能力只能在 ToolFS 自己的 command/skill API 里控制 |
| 10 | 「两种路径别名任一命中即放行」 | v3 | 会把冲突数据合并成更高权限。v4 改为规范化后单次匹配 + 只读优先 |
| 11 | copy 型快照作为非 btrfs 降级 | v1, v2 | O(数据量) 全量拷贝，TB 级 `/DATA` 上又慢又占空间，且拷贝期间数据仍在变化、拿不到一致时间点。它要解决的误删场景已被 O(1) 的 versions + trash 覆盖。v5 改为明确 `ErrSnapshotUnsupported` |
| 12 | 普通用户可执行整卷回滚 | v2 | 快照粒度是 subvolume，RBAC 粒度是 per-user 路径前缀。一个用户的回滚会覆盖所有人的数据。v5 拆成「快照=系统级只读」+「闪回=用户级受 Grant 约束写回」 |
| 13 | 按快照创建时的授权判定恢复权限 | （曾评估） | 撤权后仍能通过旧快照取回数据，撤权形同虚设。必须用**当前** Grant 判定 |
| 14 | 靠遍历代码「显式跳过」`.toolfs-state` | v4 | 依赖每一处 walker 都记得排除。v5 改为把 `.toolfs-state` 建成独立 subvolume——btrfs 快照不递归嵌套 subvolume，是文件系统层面的保证 |
| 15 | admin 在文件访问层享有特权放行 | v1–v4 | ZimaOS 自身分裂：**SMB 数据驱动**（`smb.go` 无 `admin`/`role`，纯按 share 表生成 per-user conf）、**Web UI 特权驱动**（`shares.go:618` 第一行 `if role=="admin" return true`）。v5 选 SMB 侧：admin 的 share 行本就由系统自动写入（`message.go:139`），按表构建实际可见范围几乎不变，却让权限变成显式可审计、可收窄，且 root daemon 少一条绕过全部检查的代码路径 |

---

## 4. 跨版本稳定的实证结论

以下为在真实代码上写测试**实际复现**的问题（非推测），是 P0 阶段存在的依据。它们从 v2 起贯穿至今：

| 编号 | 问题 | 证据 |
|---|---|---|
| S1 | 路径穿越绕过访问控制 | `IsPathAllowed("/toolfs/data/../secret.txt") = true`，读到 mount 外文件，审计还记 `success:true` |
| S2 | 符号链接逃逸 | mount 内软链指向外部文件，`os.ReadFile` 直接跟随 |
| S3 | 只读挂载被绕过写入 | 从可写 mount 经 `../` 写入 `ReadOnly=true` mount 的本地目录 |
| S4 | 并发数据竞态 | `go test -race` 实测：`fs.mounts` 写（`toolfs.go:430`）vs 读（`toolfs.go:705`） |
| S5 | sandbox 全局 stdout 竞态 | `sandbox.go:173` 改 `os.Stdout` 与审计 `fmt.Println` 冲突（v4 补充） |
| S6 | mount 前缀边界错误 | `strings.HasPrefix("/toolfs/database", "/toolfs/data") == true`（v4 补充） |

**根因**：`normalizeVirtualPath`（`toolfs.go:346`）只做字符规范化、不清理 `..`，而 `resolvePath` 用 `filepath.Join`（会 clean）——**判定与执行用了两个不同的路径值**。

---

## 5. 贯穿各版本的不变结论

无论方案怎么改，以下事实来自对 ZimaOS 全栈的调查，不随版本变化：

- **ZimaOS 文件权限的唯一事实来源**是 `/var/lib/casaos/files.db` 的 `shares_model_dbs` 表，每行 `(samba_user, path, read_only, is_deleted)`。
- **UserService 里没有权限数据**，只有 `role` 字段；它的权限 API 只是转发给 IceWhale-Files 的代理。
- **ZimaOS 对 admin 的处理本身就分裂**：SMB 数据驱动（`smb.go` 全文无 `admin`/`role`），Web UI 特权驱动（`shares.go:618`）。admin 的 share 行由 `message.go:139` 在 samba 用户创建时自动写入——**仅当该存储 `len(shares)==0`**，已有 share 的存储不会再自动加 admin。
- **POSIX 权限完全不参与**：`force user = root` + `0777` + `nt acl support = no`，全仓库无 `chown`/`setfacl`。
- **新用户默认权限为零**，必须管理员显式授权。
- **不存在 per-user home 目录**，隔离 100% 依赖 share 表的路径白名单。
- **btrfs 快照是绿地**：磁盘用 `mkfs.btrfs` 格式化，但 `subvolume`/`snapshot` 代码零命中。
- **但主存储 `/DATA` 是 ext4，不是 btrfs**（真机实测，见下）。`mkfs.btrfs` 只作用于数据盘，系统盘由 OS 镜像层格式化为 ext4。
- **`MountToolFSWithSession` 是空壳**（`fuse_adapter.go:326`），当前 FUSE 路径完全绕过访问控制。

---

## 6. 真机实测结论（ZimaCube Pro / ZimaOS v1.7.0 / 10.0.0.75）

详见 v5 §2.5。七项结论中，**第 1 项推翻了 v5 的核心假设**：

| # | 结论 | 影响 |
|---|---|---|
| 1 | **`/DATA` 是 ext4，btrfs 只在数据盘** | 用户主数据**没有快照能力**，只有 versions+trash 兜底。快照从「全局能力」降级为「按存储可选增强」 |
| 2 | **ext4 不支持 reflink** | `/DATA` 上 versions 是 O(size) 全量拷贝，而该盘已用 87%、剩 31G。`MaxVersionFileSize` 需按剩余空间动态定 |
| 3 | btrfs 盘挂在顶层子卷、无嵌套子卷 | `.toolfs-state` 建独立子卷的方案在数据盘上可行 |
| 4 | **admin(`casaos`) 的 3 条 share 行 = `casa.casaos.conf` 的 3 个 section** | 「数据驱动 admin 视图」实证成立，改后可见范围不变 |
| 5 | **真实存在父 rw / 子 ro 的 Grant**（`HDD-Storage` rw + `HDD-Storage/rauc/temp` ro） | 最长前缀+子目录收窄不是假想场景。且暴露 SMB 缺陷：子目录只读可被父共享绕过，ToolFS 比 SMB 严格 |
| 6 | **14 行 share 中 8 行 `is_deleted=1`** | 实证「用 `/share/permission` 会造成权限放大」，§5.1 改用 `/share`+Status 过滤的决策成立 |
| 7 | `/media/ZimaOS-HD` 是指向 `/DATA` 的符号链接，且表里存的是带尾斜杠的 `/media/ZimaOS-HD/` | 路径规范化要同时处理尾斜杠、别名、以及别名本身是软链 |

## 7. 待确认的开放问题

| # | 问题 | 阻塞性质 |
|---|---|---|
| 1 | IceWhale-Files 需新增/修复逐用户 Grant 接口 | 联调阻塞 |
| 2 | public-path 规则需固化为版本化 `PublicRootProvider` 契约 | 安全阻塞 |
| 3 | agent token 如何取得、谁负责每 3h 刷新、UserID↔UID 映射 | 生产阻塞 |
| 4 | 登录/登出/重启时由谁创建、刷新、关闭 `MountHandle` | 生产阻塞 |
| 5 | 每个 backing device 可创建 reserved StateRoot，并同步配置 Files/Samba 排除 | 受保护写入阻塞 |
| 6 | ~~真机确认 `/DATA` 文件系统~~ → **已查明是 ext4**。需产品侧确认「主数据只有 versions+trash、无时间点快照」是否可接受 | ❓ 产品决策 |
| 7 | 8 月第二周节点的范围裁剪（建议验收 P0–P2，mutation 保持关闭） | 排期决策 |

---

## 8. 阅读建议

- **要实施** → 只读 [`design-rbac-snapshot.md`](design-rbac-snapshot.md)（v5）。
- **想知道某个设计为什么是现在这样** → 看本文件第 2、3 节。
- **快照与闪回** → v5 的 §7.4–7.7 已是完整设计，不需要再回头翻 v2。v2 第 6 章仅在需要了解「copy 型后端为什么被否决」时有参考价值。
